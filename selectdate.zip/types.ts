
export interface Profile {
  id: string;
  name: string;
  age: number;
  job: string;
  bio: string;
  interests: string[];
  imageUrl: string;
}

export interface Matchmaker {
  id: string;
  name: string;
  relationship: string;
  email: string;
}

export enum AppView {
  LANDING = 'landing',
  SIGN_UP = 'signup',
  CUSTOMER_DASHBOARD = 'customer_dashboard',
  MATCHMAKER_VIEW_1 = 'matchmaker_view_1',
  MATCHMAKER_VIEW_2 = 'matchmaker_view_2',
}
