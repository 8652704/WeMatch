
import React from 'react';
import { AppView } from '../types';
import HeartIcon from './icons/HeartIcon';

interface HeaderProps {
  currentView: AppView;
  onNavigate: (view: AppView) => void;
  hasProfile: boolean;
}

const Header: React.FC<HeaderProps> = ({ currentView, onNavigate, hasProfile }) => {
  const isDashboard = currentView === AppView.CUSTOMER_DASHBOARD;
  const isMatchmaker1 = currentView === AppView.MATCHMAKER_VIEW_1;
  const isMatchmaker2 = currentView === AppView.MATCHMAKER_VIEW_2;

  return (
    <header className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-50">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div 
            className="flex-shrink-0 flex items-center cursor-pointer"
            onClick={() => onNavigate(hasProfile ? AppView.CUSTOMER_DASHBOARD : AppView.LANDING)}
          >
            <HeartIcon className="h-8 w-auto text-rose-500" />
            <span className="ml-2 text-2xl font-bold text-gray-800">Wingman</span>
          </div>
          {hasProfile && (
            <div className="flex items-center space-x-2 sm:space-x-4">
              <button 
                onClick={() => onNavigate(AppView.CUSTOMER_DASHBOARD)} 
                className={`px-3 py-2 rounded-md text-sm font-medium ${isDashboard ? 'bg-rose-100 text-rose-700' : 'text-gray-500 hover:bg-gray-100'}`}
              >
                Your Dashboard
              </button>
              <button 
                onClick={() => onNavigate(AppView.MATCHMAKER_VIEW_1)}
                className={`px-3 py-2 rounded-md text-sm font-medium ${isMatchmaker1 ? 'bg-rose-100 text-rose-700' : 'text-gray-500 hover:bg-gray-100'}`}
              >
                Wingman 1 View
              </button>
              <button 
                onClick={() => onNavigate(AppView.MATCHMAKER_VIEW_2)}
                className={`px-3 py-2 rounded-md text-sm font-medium ${isMatchmaker2 ? 'bg-rose-100 text-rose-700' : 'text-gray-500 hover:bg-gray-100'}`}
              >
                Wingman 2 View
              </button>
            </div>
          )}
        </div>
      </nav>
    </header>
  );
};

export default Header;
