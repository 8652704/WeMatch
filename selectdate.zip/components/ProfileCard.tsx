
import React from 'react';
import { Profile } from '../types';
import SparklesIcon from './icons/SparklesIcon';

interface ProfileCardProps {
  profile: Profile;
  children?: React.ReactNode;
}

const ProfileCard: React.FC<ProfileCardProps> = ({ profile, children }) => {
  return (
    <div className="bg-white rounded-2xl shadow-lg overflow-hidden flex flex-col transform hover:shadow-xl transition-shadow duration-300">
      <img className="w-full h-72 object-cover" src={profile.imageUrl} alt={profile.name} />
      <div className="p-5 flex flex-col flex-grow">
        <h3 className="text-2xl font-bold text-gray-900">{profile.name}, {profile.age}</h3>
        <p className="text-sm text-gray-500 mb-3">{profile.job}</p>
        <p className="text-gray-700 flex-grow">{profile.bio}</p>
        <div className="mt-4">
            <h4 className="font-semibold text-sm mb-2 flex items-center"><SparklesIcon className="h-4 w-4 mr-1 text-rose-400"/>Interests</h4>
            <div className="flex flex-wrap gap-2">
                {profile.interests.map(interest => (
                    <span key={interest} className="bg-rose-100 text-rose-800 text-xs font-medium px-2.5 py-1 rounded-full">{interest}</span>
                ))}
            </div>
        </div>
        {children && <div className="mt-auto pt-4">{children}</div>}
      </div>
    </div>
  );
};

export default ProfileCard;
