
import React, { useState } from 'react';
import { Profile, Matchmaker } from '../types';

interface SignUpFlowProps {
  onSignUpComplete: (profile: Profile, matchmakers: Matchmaker[]) => void;
}

const SignUpFlow: React.FC<SignUpFlowProps> = ({ onSignUpComplete }) => {
  const [step, setStep] = useState(1);
  const [profile, setProfile] = useState<Partial<Profile>>({
    name: '',
    age: undefined,
    job: '',
    bio: '',
    interests: [],
    imageUrl: `https://picsum.photos/seed/${Math.random()}/600/800`,
  });
  const [matchmakers, setMatchmakers] = useState<Partial<Matchmaker>[]>([
    { name: '', relationship: '', email: '' },
    { name: '', relationship: '', email: '' }
  ]);

  const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setProfile({ ...profile, [e.target.name]: e.target.value });
  };
  
  const handleInterestsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const interests = e.target.value.split(',').map(interest => interest.trim());
    setProfile({ ...profile, interests });
  };

  const handleMatchmakerChange = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const newMatchmakers = [...matchmakers];
    newMatchmakers[index] = { ...newMatchmakers[index], [e.target.name]: e.target.value };
    setMatchmakers(newMatchmakers);
  };
  
  const validateStep1 = () => {
    return profile.name && profile.age && profile.job && profile.bio && profile.interests && profile.interests.length > 0;
  }
  
  const validateStep2 = () => {
      return matchmakers.every(mm => mm.name && mm.relationship && mm.email && mm.email.includes('@'));
  }

  const handleSubmit = () => {
    if (!validateStep2()) {
        alert("Please fill out all matchmaker fields correctly.");
        return;
    }
    const finalProfile: Profile = {
        id: `user-${new Date().getTime()}`,
        ...profile
    } as Profile;

    const finalMatchmakers: Matchmaker[] = matchmakers.map((mm, i) => ({
        id: `mm-${i}-${new Date().getTime()}`,
        ...mm
    })) as Matchmaker[];
    
    onSignUpComplete(finalProfile, finalMatchmakers);
  };

  return (
    <div className="max-w-2xl mx-auto bg-white p-8 rounded-2xl shadow-lg">
      <h2 className="text-3xl font-bold text-center text-gray-800 mb-2">Create Your Circle</h2>
      <p className="text-center text-gray-500 mb-8">Let's get you set up. First your profile, then your matchmakers.</p>
      
      {step === 1 && (
        <div>
          <h3 className="text-xl font-semibold mb-4 text-rose-600">Step 1: Tell us about you</h3>
          <div className="space-y-4">
            <input type="text" name="name" placeholder="Your Name" onChange={handleProfileChange} className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-rose-400" />
            <input type="number" name="age" placeholder="Your Age" onChange={handleProfileChange} className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-rose-400" />
            <input type="text" name="job" placeholder="Your Job" onChange={handleProfileChange} className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-rose-400" />
            <textarea name="bio" placeholder="Your Bio" onChange={handleProfileChange} rows={3} className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-rose-400" />
            <input type="text" name="interests" placeholder="Your Interests (comma separated)" onChange={handleInterestsChange} className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-rose-400" />
          </div>
          <button onClick={() => setStep(2)} disabled={!validateStep1()} className="mt-6 w-full bg-rose-500 text-white p-3 rounded-lg font-semibold hover:bg-rose-600 disabled:bg-gray-300">Next: Invite Your Wingmen</button>
        </div>
      )}

      {step === 2 && (
        <div>
          <h3 className="text-xl font-semibold mb-4 text-rose-600">Step 2: Invite Your Matchmakers</h3>
          <p className="text-sm text-gray-500 mb-4">You need at least two. They'll get an email inviting them to pick matches for you.</p>
          <div className="space-y-6">
            {matchmakers.map((mm, index) => (
              <div key={index} className="p-4 border rounded-lg">
                <h4 className="font-semibold mb-2">Matchmaker {index + 1}</h4>
                <div className="space-y-3">
                    <input type="text" name="name" placeholder="Name" value={mm.name || ''} onChange={(e) => handleMatchmakerChange(index, e)} className="w-full p-2 border rounded-md" />
                    <input type="text" name="relationship" placeholder="Relationship (e.g., Best Friend)" value={mm.relationship || ''} onChange={(e) => handleMatchmakerChange(index, e)} className="w-full p-2 border rounded-md" />
                    <input type="email" name="email" placeholder="Email" value={mm.email || ''} onChange={(e) => handleMatchmakerChange(index, e)} className="w-full p-2 border rounded-md" />
                </div>
              </div>
            ))}
          </div>
          <div className="flex items-center space-x-4 mt-6">
              <button onClick={() => setStep(1)} className="w-full bg-gray-200 text-gray-700 p-3 rounded-lg font-semibold hover:bg-gray-300">Back</button>
              <button onClick={handleSubmit} disabled={!validateStep2()} className="w-full bg-rose-500 text-white p-3 rounded-lg font-semibold hover:bg-rose-600 disabled:bg-gray-300">Finish & View Dashboard</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default SignUpFlow;
