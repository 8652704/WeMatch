
import React from 'react';
import SparklesIcon from './icons/SparklesIcon';
import UsersIcon from './icons/UsersIcon';
import HeartIcon from './icons/HeartIcon';

interface LandingPageProps {
  onGetStarted: () => void;
}

const FeatureCard: React.FC<{ icon: React.ReactNode; title: string; description: string }> = ({ icon, title, description }) => (
    <div className="bg-white p-6 rounded-xl shadow-lg transform hover:scale-105 transition-transform duration-300">
        <div className="flex items-center justify-center h-12 w-12 rounded-full bg-rose-100 text-rose-500 mb-4">
            {icon}
        </div>
        <h3 className="text-xl font-semibold mb-2">{title}</h3>
        <p className="text-gray-600">{description}</p>
    </div>
);

const LandingPage: React.FC<LandingPageProps> = ({ onGetStarted }) => {
  return (
    <div className="text-center">
      <div className="relative isolate overflow-hidden bg-gradient-to-b from-rose-100/20 pt-14">
        <div className="absolute inset-y-0 right-1/2 -z-10 -mr-96 w-[200%] origin-top-right skew-x-[-30deg] bg-white shadow-xl shadow-rose-600/10 ring-1 ring-rose-50 sm:mr-20 lg:mr-0 lg:origin-center lg:skew-x-0"></div>
        <div className="py-24 sm:py-32">
            <h1 className="text-4xl sm:text-6xl font-bold tracking-tight text-gray-900">
                Let your friends play cupid.
            </h1>
            <p className="mt-6 text-lg leading-8 text-gray-600 max-w-2xl mx-auto">
                Tired of swiping? Invite your friends and family to be your personal matchmakers. They pick the profiles, you pick the date. It's dating, with a little help from your friends.
            </p>
            <div className="mt-10">
                <button
                    onClick={onGetStarted}
                    className="rounded-md bg-rose-500 px-6 py-3 text-lg font-semibold text-white shadow-sm hover:bg-rose-600 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-rose-600 transition-transform transform hover:scale-105"
                >
                    Get Started
                </button>
            </div>
        </div>
      </div>

      <div className="py-24 sm:py-32">
        <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl mb-16">How It Works</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <FeatureCard 
                icon={<UsersIcon />}
                title="1. Assemble Your Crew"
                description="Create your profile and invite the friends and family you trust most to be your 'Wingmen'."
            />
            <FeatureCard 
                icon={<SparklesIcon />}
                title="2. They Pick Your Matches"
                description="Your Wingmen browse and select potential matches they think you'll love, creating a curated pool just for you."
            />
            <FeatureCard 
                icon={<HeartIcon />}
                title="3. You Make the Connection"
                description="Review the hand-picked candidates. If you see someone you like, it's a match! We even suggest a group first date."
            />
        </div>
      </div>
    </div>
  );
};

export default LandingPage;
