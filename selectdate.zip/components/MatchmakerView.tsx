
import React from 'react';
import { Profile, Matchmaker } from '../types';
import ProfileCard from './ProfileCard';
import HeartIcon from './icons/HeartIcon';

interface MatchmakerViewProps {
  matchmaker: Matchmaker;
  customerProfile: Profile;
  candidates: Profile[];
  selections: string[];
  onSelectCandidate: (matchmakerId: string, candidateId: string) => void;
}

const MatchmakerView: React.FC<MatchmakerViewProps> = ({ matchmaker, customerProfile, candidates, selections, onSelectCandidate }) => {
  return (
    <div>
      <div className="bg-white p-6 rounded-2xl shadow-md mb-8 text-center">
        <h1 className="text-3xl font-bold text-gray-800">Playing Cupid for {customerProfile.name}</h1>
        <p className="text-gray-600 mt-2">You are <span className="font-semibold text-rose-500">{matchmaker.name}</span> ({matchmaker.relationship}). Browse the profiles below and pick who you think is a great match!</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {candidates.map(candidate => {
          const isSelected = selections.includes(candidate.id);
          return (
            <ProfileCard key={candidate.id} profile={candidate}>
              <button 
                onClick={() => onSelectCandidate(matchmaker.id, candidate.id)}
                className={`mt-4 w-full flex items-center justify-center font-bold py-2 px-4 rounded-full transition-colors duration-300 ${
                  isSelected 
                    ? 'bg-rose-500 text-white hover:bg-rose-600' 
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                <HeartIcon className={`h-5 w-5 mr-2 ${isSelected ? 'text-white' : 'text-rose-500'}`} />
                {isSelected ? 'Selected for ' + customerProfile.name : 'Pick for ' + customerProfile.name}
              </button>
            </ProfileCard>
          )
        })}
      </div>
    </div>
  );
};

export default MatchmakerView;
