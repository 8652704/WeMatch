
import React, { useState } from 'react';
import { Profile, Matchmaker } from '../types';
import ProfileCard from './ProfileCard';
import HeartIcon from './icons/HeartIcon';
import UsersIcon from './icons/UsersIcon';
import MessageIcon from './icons/MessageIcon';

interface CustomerDashboardProps {
  userProfile: Profile;
  matchmakers: Matchmaker[];
  selectedCandidates: Profile[];
  matches: Profile[];
  onMatch: (candidate: Profile) => void;
}

const CustomerDashboard: React.FC<CustomerDashboardProps> = ({ userProfile, matchmakers, selectedCandidates, matches, onMatch }) => {
    const [activeTab, setActiveTab] = useState<'picks' | 'matches'>('picks');
    
    const candidatesToShow = selectedCandidates.filter(c => !matches.find(m => m.id === c.id));

    return (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column: User Profile & Matchmakers */}
            <div className="lg:col-span-1 space-y-8">
                <div className="bg-white p-6 rounded-2xl shadow-md">
                    <h2 className="text-2xl font-bold mb-4">Your Profile</h2>
                    <div className="flex items-center space-x-4">
                        <img src={userProfile.imageUrl} alt={userProfile.name} className="w-20 h-20 rounded-full object-cover"/>
                        <div>
                            <h3 className="text-xl font-bold">{userProfile.name}, {userProfile.age}</h3>
                            <p className="text-gray-600">{userProfile.job}</p>
                        </div>
                    </div>
                    <p className="mt-4 text-gray-700">{userProfile.bio}</p>
                </div>

                <div className="bg-white p-6 rounded-2xl shadow-md">
                    <h2 className="text-2xl font-bold mb-4 flex items-center"><UsersIcon className="mr-2 h-6 w-6 text-rose-500"/> Your Wingmen</h2>
                    <ul className="space-y-4">
                        {matchmakers.map(mm => (
                            <li key={mm.id} className="flex items-center space-x-3">
                                <div className="bg-rose-100 text-rose-600 font-bold rounded-full h-10 w-10 flex items-center justify-center">
                                    {mm.name.charAt(0)}
                                </div>
                                <div>
                                    <p className="font-semibold">{mm.name}</p>
                                    <p className="text-sm text-gray-500">{mm.relationship}</p>
                                </div>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>

            {/* Right Column: Candidates and Matches */}
            <div className="lg:col-span-2">
                <div className="bg-white p-6 rounded-2xl shadow-md min-h-[400px]">
                    <div className="flex border-b mb-4">
                        <button onClick={() => setActiveTab('picks')} className={`px-4 py-2 text-lg font-semibold ${activeTab === 'picks' ? 'border-b-2 border-rose-500 text-rose-600' : 'text-gray-500'}`}>
                            Picks from your friends ({candidatesToShow.length})
                        </button>
                        <button onClick={() => setActiveTab('matches')} className={`px-4 py-2 text-lg font-semibold ${activeTab === 'matches' ? 'border-b-2 border-rose-500 text-rose-600' : 'text-gray-500'}`}>
                            Your Matches ({matches.length})
                        </button>
                    </div>

                    {activeTab === 'picks' && (
                        <div>
                            {candidatesToShow.length > 0 ? (
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    {candidatesToShow.map(candidate => (
                                        <ProfileCard key={candidate.id} profile={candidate}>
                                             <button onClick={() => onMatch(candidate)} className="mt-4 w-full flex items-center justify-center bg-green-500 text-white font-bold py-2 px-4 rounded-full hover:bg-green-600 transition-colors duration-300">
                                                <HeartIcon className="h-5 w-5 mr-2" /> Match
                                            </button>
                                        </ProfileCard>
                                    ))}
                                </div>
                            ) : (
                                <div className="text-center py-16">
                                    <h3 className="text-xl font-semibold text-gray-700">All Caught Up!</h3>
                                    <p className="text-gray-500 mt-2">You've reviewed all the picks from your friends. Check back later for more!</p>
                                </div>
                            )}
                        </div>
                    )}
                    
                    {activeTab === 'matches' && (
                        <div>
                            {matches.length > 0 ? (
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    {matches.map(match => (
                                        <ProfileCard key={match.id} profile={match}>
                                             <div className="mt-4 text-center">
                                                <p className="text-sm text-green-600 font-semibold mb-2">It's a Match!</p>
                                                <button className="w-full flex items-center justify-center bg-rose-500 text-white font-bold py-2 px-4 rounded-full hover:bg-rose-600 transition-colors duration-300">
                                                   <MessageIcon className="h-5 w-5 mr-2"/> Start Chat
                                                </button>
                                                <p className="text-xs text-gray-500 mt-2">Pro-tip: Suggest a group first date with your Wingmen!</p>
                                             </div>
                                        </ProfileCard>
                                    ))}
                                </div>
                            ) : (
                                <div className="text-center py-16">
                                    <h3 className="text-xl font-semibold text-gray-700">No Matches Yet</h3>
                                    <p className="text-gray-500 mt-2">Go to the "Picks" tab to see who your friends have chosen for you.</p>
                                </div>
                            )}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default CustomerDashboard;
