
import { Profile, Matchmaker } from '../types';

export const MOCK_USER_PROFILE: Profile = {
    id: 'user-main',
    name: 'Alex',
    age: 28,
    job: 'Product Designer',
    bio: "Loves spontaneous weekend trips, finding the best ramen spots, and re-watching old sci-fi movies. Looking for someone who can make me laugh and doesn't mind my questionable taste in music.",
    interests: ['Hiking', 'Photography', 'Live Music', 'Cooking', 'Sci-Fi Films'],
    imageUrl: 'https://picsum.photos/seed/alex/600/800'
};

export const MOCK_MATCHMAKERS: Matchmaker[] = [
    { id: 'mm-1', name: 'Chloe', relationship: 'Best Friend', email: 'chloe@example.com' },
    { id: 'mm-2', name: 'David', relationship: 'Brother', email: 'david@example.com' }
];

export const MOCK_CANDIDATES: Profile[] = [
    {
        id: 'candidate-1',
        name: 'Jordan',
        age: 29,
        job: 'Software Engineer',
        bio: 'Just a guy who loves dogs, rock climbing, and building cool things. My ideal weekend involves a mountain and a craft beer. Let\'s build a connection, not just a project.',
        interests: ['Rock Climbing', 'Craft Beer', 'Dogs', 'Woodworking'],
        imageUrl: 'https://picsum.photos/seed/jordan/600/800'
    },
    {
        id: 'candidate-2',
        name: 'Riley',
        age: 27,
        job: 'Graphic Designer',
        bio: 'Fluent in sarcasm and watercolors. I spend my time visiting art museums, trying new vegan recipes, and getting lost in new cities. Looking for a partner in crime for creative adventures.',
        interests: ['Art', 'Vegan Cooking', 'Travel', 'Indie Films'],
        imageUrl: 'https://picsum.photos/seed/riley/600/800'
    },
    {
        id: 'candidate-3',
        name: 'Casey',
        age: 31,
        job: 'Nurse',
        bio: 'I have a big heart and a bigger coffee addiction. When I\'m not saving lives, I\'m usually at a concert, playing beach volleyball, or with my golden retriever, Sunny.',
        interests: ['Live Music', 'Beach Volleyball', 'Dogs', 'Coffee'],
        imageUrl: 'https://picsum.photos/seed/casey/600/800'
    },
    {
        id: 'candidate-4',
        name: 'Taylor',
        age: 26,
        job: 'Architect',
        bio: 'Designing buildings by day, exploring cityscapes by night. I appreciate good design, a compelling book, and deep conversations over a glass of wine.',
        interests: ['Architecture', 'Reading', 'Wine Tasting', 'Urban Exploration'],
        imageUrl: 'https://picsum.photos/seed/taylor/600/800'
    },
    {
        id: 'candidate-5',
        name: 'Morgan',
        age: 30,
        job: 'Chef',
        bio: 'My love language is food. I believe every meal should be an experience. If you enjoy farmers markets, trying exotic foods, and don\'t mind a little kitchen chaos, we\'ll get along great.',
        interests: ['Cooking', 'Farmers Markets', 'Foodie', 'Sailing'],
        imageUrl: 'https://picsum.photos/seed/morgan/600/800'
    },
    {
        id: 'candidate-6',
        name: 'Sam',
        age: 28,
        job: 'Musician',
        bio: 'I play guitar in a band and write songs about life. I\'m passionate about music, history, and finding the perfect vintage t-shirt. Let\'s find a new record store to explore.',
        interests: ['Guitar', 'History', 'Thrifting', 'Vinyl Records'],
        imageUrl: 'https://picsum.photos/seed/sam/600/800'
    }
];
