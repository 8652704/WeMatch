
import { GoogleGenAI, Type } from "@google/genai";
import { Profile } from "../types";

// This file is for demonstrating how mock data could be generated.
// The app uses pre-generated mock data from mockData.ts for stability.

const generateMockProfiles = async (count: number): Promise<Profile[] | null> => {
  if (!process.env.API_KEY) {
    console.error("API_KEY environment variable not set.");
    return null;
  }
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Generate ${count} diverse and realistic dating profiles. Ensure a mix of genders, jobs, and interests. Bios should be creative and in the first person.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            profiles: {
              type: Type.ARRAY,
              description: "A list of generated user profiles.",
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING, description: "A unique ID for the profile (e.g., 'candidate-1')."},
                  name: { type: Type.STRING, description: "The person's first name." },
                  age: { type: Type.INTEGER, description: "The person's age." },
                  job: { type: Type.STRING, description: "The person's job or profession." },
                  bio: {
                    type: Type.STRING,
                    description: "A short, engaging bio written in the first person.",
                  },
                  interests: {
                    type: Type.ARRAY,
                    description: "A list of 4-5 hobbies or interests.",
                    items: { type: Type.STRING },
                  },
                  imageUrl: {
                    type: Type.STRING,
                    description: "A placeholder image URL from picsum.photos with a unique seed (e.g., 'https://picsum.photos/seed/john/600/800').",
                  },
                },
              },
            },
          },
        },
      },
    });

    const jsonText = response.text.trim();
    const result = JSON.parse(jsonText);
    return result.profiles;

  } catch (error) {
    console.error("Error generating profiles with Gemini:", error);
    return null;
  }
};

export default generateMockProfiles;
