
import React, { useState, useCallback } from 'react';
import { AppView, Profile, Matchmaker } from './types';
import { MOCK_USER_PROFILE, MOCK_MATCHMAKERS, MOCK_CANDIDATES } from './services/mockData';
import LandingPage from './components/LandingPage';
import SignUpFlow from './components/SignUpFlow';
import CustomerDashboard from './components/CustomerDashboard';
import MatchmakerView from './components/MatchmakerView';
import Header from './components/Header';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>(AppView.LANDING);
  const [userProfile, setUserProfile] = useState<Profile | null>(null);
  const [matchmakers, setMatchmakers] = useState<Matchmaker[]>([]);
  const [candidates] = useState<Profile[]>(MOCK_CANDIDATES);
  const [selections, setSelections] = useState<Record<string, string[]>>({}); // matchmakerId -> profileId[]
  const [matches, setMatches] = useState<Profile[]>([]);

  const handleSignUpComplete = (profile: Profile, newMatchmakers: Matchmaker[]) => {
    setUserProfile(profile);
    setMatchmakers(newMatchmakers);
    // Simulate matchmakers already making some picks for demo purposes
    setSelections({
      [newMatchmakers[0].id]: [MOCK_CANDIDATES[1].id, MOCK_CANDIDATES[3].id],
      [newMatchmakers[1].id]: [MOCK_CANDIDATES[0].id, MOCK_CANDIDATES[1].id, MOCK_CANDIDATES[4].id],
    });
    setCurrentView(AppView.CUSTOMER_DASHBOARD);
  };

  const handleSelectCandidate = useCallback((matchmakerId: string, candidateId: string) => {
    setSelections(prev => {
      const currentSelections = prev[matchmakerId] || [];
      if (currentSelections.includes(candidateId)) {
        return {
          ...prev,
          [matchmakerId]: currentSelections.filter(id => id !== candidateId)
        };
      } else {
        return {
          ...prev,
          [matchmakerId]: [...currentSelections, candidateId]
        };
      }
    });
  }, []);
  
  const handleMatch = (candidate: Profile) => {
    if (!matches.find(m => m.id === candidate.id)) {
        setMatches(prev => [...prev, candidate]);
    }
  };

  const renderView = () => {
    switch (currentView) {
      case AppView.LANDING:
        return <LandingPage onGetStarted={() => setCurrentView(AppView.SIGN_UP)} />;
      case AppView.SIGN_UP:
        return <SignUpFlow onSignUpComplete={handleSignUpComplete} />;
      case AppView.CUSTOMER_DASHBOARD:
        if (!userProfile) {
            setCurrentView(AppView.SIGN_UP);
            return null;
        }
        const candidateIds = [...new Set(Object.values(selections).flat())];
        const selectedCandidates = candidates.filter(c => candidateIds.includes(c.id));
        return <CustomerDashboard 
            userProfile={userProfile} 
            matchmakers={matchmakers}
            selectedCandidates={selectedCandidates}
            matches={matches}
            onMatch={handleMatch}
        />;
      case AppView.MATCHMAKER_VIEW_1:
        if (!userProfile) return null;
        return <MatchmakerView
            matchmaker={matchmakers[0] || MOCK_MATCHMAKERS[0]}
            customerProfile={userProfile}
            candidates={candidates}
            onSelectCandidate={handleSelectCandidate}
            selections={selections[matchmakers[0]?.id || MOCK_MATCHMAKERS[0].id] || []}
        />;
      case AppView.MATCHMAKER_VIEW_2:
        if (!userProfile) return null;
        return <MatchmakerView
            matchmaker={matchmakers[1] || MOCK_MATCHMAKERS[1]}
            customerProfile={userProfile}
            candidates={candidates}
            onSelectCandidate={handleSelectCandidate}
            selections={selections[matchmakers[1]?.id || MOCK_MATCHMAKERS[1].id] || []}
        />;
      default:
        return <LandingPage onGetStarted={() => setCurrentView(AppView.SIGN_UP)} />;
    }
  };

  return (
    <div className="bg-gray-50 min-h-screen text-gray-800">
      <Header currentView={currentView} onNavigate={setCurrentView} hasProfile={!!userProfile} />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderView()}
      </main>
    </div>
  );
};

export default App;
